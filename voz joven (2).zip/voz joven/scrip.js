// Puedes agregar interacciones en el futuro si lo deseas
console.log("¡Voz Joven Online está en vivo!");
